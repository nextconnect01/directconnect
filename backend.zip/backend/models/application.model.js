import mongoose,{Schema} from "mongoose"

const applicationSchema = new Schema(
    {
        status : {
            type : String,
            enum : ["accepted","rejected","pending"],
            default : "pending"
        },
        applicant : [{
            type : Schema.Types.ObjectId,
            ref : "User",
            required : true
        }],
        owner : {
            type : Schema.Types.ObjectId,
            ref : "User",
        },
        job : {
            type : Schema.Types.ObjectId,
            ref : "Job",
            requied : true
        }

    },
    {timestamps : true}
)

export const Application =  mongoose.model("Application",applicationSchema)