import express from "express"
import { isAuthenticated } from "../middleware/isAuthenticated.js"
import { applyJob, getAcceptedJobs, getApplicant, getAppliedJobs, updateStatus } from "../controllers/application.controller.js"
const router = express.Router()

router.route("/applyJobs/:id").get(isAuthenticated,applyJob)
router.route("/getApplicants/:id").get(isAuthenticated,getApplicant)
router.route("/getAppliedJobs").get(isAuthenticated,getAppliedJobs)
router.route("/updateStatus/:id").post(isAuthenticated,updateStatus)
router.route("/getAcceptedJobs").get(isAuthenticated,getAcceptedJobs)

export default router