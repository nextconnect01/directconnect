import express from "express"
import { isAuthenticated } from "../middleware/isAuthenticated.js"
import { adminAlljobs, allJobs, createJob, deleteJob, getClientAllJobs, getJobById, markJobAsCompleted, raiseJobDispute, updateJob, updatePausedJobStatus } from "../controllers/job.controller.js"

const router = express.Router()

router.route("/postJob").post(isAuthenticated,createJob)
router.route("/deleteJob/:id").delete(isAuthenticated,deleteJob)
router.route("/adminJobs").get(isAuthenticated,adminAlljobs)
router.route("/getAllJobs").get(isAuthenticated,allJobs)
router.route("/updateJob/:id").post(isAuthenticated,updateJob)
router.route("/jobById/:id").get(isAuthenticated,getJobById)
router.route("/clientJobs").get(isAuthenticated,getClientAllJobs)
router.route("/:id/completeJob").put(isAuthenticated,markJobAsCompleted)
router.route("/:id/feedBackStatus").put(isAuthenticated,updatePausedJobStatus)
router.route("/:id/disputedJob").put(isAuthenticated,raiseJobDispute)

export default router