import { Application } from "../models/application.model.js";
import { Job } from "../models/job.models.js";
import { User } from "../models/user.model.js";

export const applyJob = async (req, res) => {
  try {
    const userId = req.id;
    const jobId = req.params.id;

    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        message: "No such job found",
        success: false,
      });
    }

    const user = await User.findById(userId)
    if(!user){
      return res.status(404).json({
        message : "No such user is found",
        success : false
      })
    }

    const existingApplication = await Application.findOne({
      job: jobId,
      applicant: userId,
    });
    if (existingApplication) {
      return res.status(400).json({
        message: "Already Applied For this job",
        success: false,
        job
      });
    }

    const newApplication = await Application.create({
      applicant: userId,
      job: jobId,
    });

    await User.findByIdAndUpdate(userId, {
      $addToSet: { proposalsSent: newApplication._id }
    });

    await job.application.push(newApplication._id);
    await job.save();

    return res.status(201).json({
      message: "Successfully Applied for the job",
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
    });
  }
};

export const getApplicant = async (req, res) => {
  try {
    const userId = req.id;
    const jobId = req.params.id;

    const job = await Job.findById(jobId).populate({
      path: "application",
      option: { sorted: { createdBy: -1 } },
      populate: {
        path: "applicant",
      },
    });

    if (!job) {
      return res.status(404).json({
        message: "No such JOB found",
        success: false,
      });
    }

    return res.status(200).json({
      message: "Applicants Found",
      success: true,
      job,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const updateStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const applicationId = req.params.id;

    const application = await Application.findById(applicationId).populate({
      path: "job",
    });

    if (!application) {
      return res.status(400).json({
        message: "No Such Application found",
        success: false,
      });
    }

    const client = await User.findById(application?.job?.owner);

    if (!client) {
      return res.status(404).json({
        message: "No Client is found",
        success: false,
      });
    }

    const job = await Job.findOne({ _id: application.job._id });


    application.status = status;

    if(application.status === "rejected"){
      
      for (const applicantId of application?.applicant){
        await User.findByIdAndUpdate(applicantId,{
          $addToSet : {rejectedJobs : application?.job?._id}
        })
      }

      await Application.findByIdAndDelete(applicationId);
      return res.status(200).json({
        message : "Application Rejected",
        success : true
      })
    }

    if (application.status === "accepted") {
      
      for(const applicationId of application.applicant){
        await User.findByIdAndUpdate(applicationId,{
          $addToSet : {activeJobs : job?._id}
        })
      }

      await User.findByIdAndUpdate(client._id, {
        $addToSet: { connectedFreelancers: application.applicant },
      });
      await Job.findByIdAndUpdate(application?.job?._id,{
        $addToSet : {freelancerAccepted : application.applicant} 
      })
      if (job) {
        job.status = "progress";
        await job.save();
      }
    }
    await application.save();

    return res.status(200).json({
      message: "Status Updated Successfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: true,
    });
  }
};

export const getAppliedJobs = async (req, res) => {
  try {
    const userId = req.id;
    const applications = await Application.find({ applicant: userId })
      .sort({ createdAt: -1 })
      .populate({
        path: "job",
        options: { sort: { createdAt: -1 } },
      });

    if (!applications) {
      return res.status(404).json({
        message: "No such Application",
        success: false,
      });
    }

    return res.status(200).json({
      message: "All Applications Found",
      success: true,
      applications,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const getAcceptedJobs = async (req, res) => {
  try {
    const userId = req.id;
    if(!userId){
        return res.status(404).json({
            message : "No such user found",
            success : false
        })
    }
    const applications = await Application.find({
      applicant: userId,
      status: "accepted",
    })
      .sort({ createdAt: -1 })
      .populate({
        path: "job",
        options: { sort: { createdAt: -1 } },
        populate: {
          path: "owner", // This assumes "owner" is a ref inside Job model
        },
      });

    if(!applications){
        return res.status(404).json({
            message : "No such application found",
            success : false
        })
    }

    return res.status(200).json({
        message : "Accepted Application AND jobs found",
        success : true,
        applications
    })

  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};
