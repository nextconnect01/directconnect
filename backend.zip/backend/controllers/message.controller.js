import cloudinary from "../db/cloudinary.js"
import { Conversation } from "../models/conversation.model.js"
import { Message } from "../models/message.model.js"
import { User } from "../models/user.model.js"
import { getRecieverSocketId,io } from "../socket.js"

export const sendMessage = async (req,res) => {
    try {
        const ladka = req.id
        const ladki = req.params.id
        const {message} = req.body
        const file = req.files?.messageFile?.[0]
        let conversation = await Conversation.findOne({
            participants : {$all : [ladka,ladki]}
        })

        if (!conversation){
            conversation = await Conversation.create({
                participants : [ladka,ladki]
            })
        }

        const newMessageData = {
            sendersId : ladka,
            recieversId : ladki,
            
        }

        if(message){
            newMessageData.message =  message;
            newMessageData.fileType = "text"
        }
        if(file){
            const uploadedFile = await cloudinary.uploader.upload(
                `data:${file.mimetype};base64,${file.buffer.toString("base64")}`
            );            if(!uploadedFile){
                return res.status(404).json({
                    message : "File Upload Failed",
                    success : false
                })
            }

            newMessageData.fileUrl = uploadedFile.secure_url
            newMessageData.fileType = file.mimetype.split("/")[1]
        }

        const newMessage = await Message.create(newMessageData)
        if(newMessage){
            conversation.messages.push(newMessage._id)
        }

        await Promise.all([conversation.save(),newMessage.save()])

        const recieverSocketId = getRecieverSocketId(ladki)
        if(recieverSocketId){
            io.to(recieverSocketId).emit('newMessage',newMessage)
            const sender = await User.findById(ladka).select("username profile.profilePhoto")
            const messageNotification = {
                type : "message",
                userId : ladka,
                userDetails : sender,
                message : "Sent You A Message"
            }
            console.log('Sending Notification',messageNotification);

            io.to(recieverSocketId).emit('notification',messageNotification)
            
        }

        return res.status(200).json({
            message : "Message Sent Successfully",
            success : true,
            newMessage
        })
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            message : "Internal Server Error",
            success : false
        })
    }
}

export const getMessage = async (req,res) => {
    try {
        const ladka = req.id
        const ladki = req.params.id
        

        const conversation = await Conversation.findOne({
            participants : {$all : [ladka,ladki]}
        }).populate('messages')

        if(!conversation){
            return res.status(200).json({
                message : [],
                success : true
            })
        }

        return res.status(200).json({
            message : conversation?.messages,
            success : true
        })
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            message : "Internal Server Error",
            success : false
        })
        
    }
}

export const getClientContacts = async (req, res) => {
    try {
      const currentUserId = req.id;
  
      // Find all conversations that include this user
      const conversations = await Conversation.find({
        participants: currentUserId,
      });
  
      // Collect the other participants (i.e., not the logged-in user)
      const otherUserIds = new Set();
  
      conversations.forEach((conv) => {
        conv.participants.forEach((participantId) => {
          if (participantId.toString() !== currentUserId) {
            otherUserIds.add(participantId.toString());
          }
        });
      });
  
      // Fetch only clients from those users
      const clients = await User.find({
        _id: { $in: Array.from(otherUserIds) },
        role: "client",
      }).select("_id username avatar email profile.profilePhoto");
  
      return res.status(200).json({
        success: true,
        clients,
      });
  
    } catch (err) {
      console.error("Error in getClientContacts:", err);
      return res.status(500).json({
        success: false,
        message: "Internal Server Error",
      });
    }
  };