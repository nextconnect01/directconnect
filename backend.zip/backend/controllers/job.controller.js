import { Job } from "../models/job.models.js";
import { User } from "../models/user.model.js";

export const createJob = async (req, res) => {
  try {
    const {
      title,
      description,
      salary,
      duration,
      skills,
      rank,
      jobType,
      applicationDeadline,
      budgetType,
      category,
    } = req.body;
    const ownerId = req.id;
    if (!ownerId) {
      return res.status(401).json({
        message: "Not Authenticated",
        success: false,
      });
    }
    if (
      !title ||
      !description ||
      !salary ||
      !duration ||
      !skills ||
      !rank ||
      !applicationDeadline ||
      !budgetType ||
      !category ||
      !jobType
    ) {
      return res.status(404).json({
        message: "Something is Missing",
        success: false,
      });
    }

    const job = await Job.create({
      title,
      description,
      duration,
      salary,
      rank,
      skills,
      owner: ownerId,
      applicationDeadline,
      budgetType,
      category,
      jobType,
    });

    if (!job) {
      return res.status(400).json({
        message: "Job Not Created",
        success: false,
      });
    }

    return res.status(201).json({
      message: "Job Created Successfully",
      success: true,
      job,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const updateJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    const userId = req.id;

    const job = await Job.findById(jobId);

    if (!job) {
      return res.status(404).json({
        message: "Job noT Found",
        success: false,
      });
    }
    const {
      title,
      description,
      salary,
      duration,
      skills,
      rank,
      jobType,
      applicationDeadline,
      budgetType,
      category,
    } = req.body;
    

    if (job?.owner?._id.toString() !== userId) {
      return res.status(403).json({
        message: "You are not authorized to updated this job",
        success: false,
      });
    }

    const updatedJob = await Job.findByIdAndUpdate(jobId, {
      title,
      description,
      salary,
      duration,
      skills,
      rank,
      jobType,
      applicationDeadline,
      budgetType,
      category
    });

    return res.status(200).json({
      message: "Job updated successfully",
      success: true,
      job: updatedJob,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const deleteJob = async (req, res) => {
  try {
    const ownerId = req.id;
    const jobId = req.params.id;
    let job = await Job.findOne({ _id: jobId, owner: ownerId });
    if (!job) {
      return res.status(404).json({
        message: "No Such Job Exist",
        success: false,
      });
    }

    await Job.deleteOne({ _id: jobId });

    return res.status(200).json({
      message: "Job Deleted Successfully",
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const adminAlljobs = async (req, res) => {
  try {
    const ownerId = req.id;
    const jobs = await Job.find({ owner: ownerId })
      .populate({ path: "owner" })
      .populate({ path: "application" , populate :{
        path : "applicant"
      }});
    if (!jobs) {
      return res.status(404).json({
        message: "No Job present for this user",
        success: false,
      });
    }

    return res.status(200).json({
      message: "All the jobs of the user",
      success: true,
      jobs,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: "false",
    });
  }
};

export const allJobs = async (req, res) => {
  try {
    const userId = req.id
    const user = await User.findById(userId)
    if(!user){
      return res.status(404).json({
        message : ""
      })
    }
    const keyword = req.query.keyword || "";
    const query = {
      $and: [
        { status: "active" },
        {
          _id : {$nin : user.rejectedJobs || []} // exclude rejected jobs
        },
        {
          $or: [
            { title: { $regex: keyword, $options: "i" } },
            { description: { $regex: keyword, $options: "i" } },
          ],
        },
      ],
    };

    const jobs = await Job.find(query).populate({ path: "owner" }).populate({path : "application"});
    if (!jobs.length) {
      return res.status(400).json({
        message: "No Jobs found",
        success: false,
      });
    }

    return res.status(200).json({
      message: "Jobs Found",
      success: true,
      jobs,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const getJobById = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await User.findById(jobId).populate({ path: "application" });
    if (!job) {
      return res.status(404).json({
        message: "NO Such job found",
        success: false,
      });
    }

    return res.status(200).json({
      message: "jOB Found",
      success: true,
      job,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const getClientAllJobs = async (req, res) => {
  try {
    const clientId = req.params.id;
    const jobs = await Job.find({ owner: clientId });
    if (jobs.length === 0) {
      return res.status(404).json({
        message: "NO jobs posted by this client",
        success: false,
      });
    }

    return res.status(200).json({
      message: "All the jobs found",
      success: true,
      jobs,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const markJobAsCompleted = async (req, res) => {
  try {
    const jobId = req.params.id;
    const userId = req.id;
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        message: "No such job found",
        success: false,
      });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        message: "No Such User Found",
        success: false,
      });
    }

    if (user?.role === "freelancer") {
      job.status = "paused";
      await job.save();
      return res.status(200).json({
        message: "Job Submission For work Submission",
        success: true,
        job,
      });
    }

    if (user?.role === "client") {
      job.status = "completed";
      await job.save();
      return res.status(200).json({
        message: "Job Marked As Completed",
        success: true,
        job
      });
    }

    return res.status(400).json({
      message: "You are not authorized to take this action",
      success: false,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal server Error",
      success: false,
    });
  }
};

export const updatePausedJobStatus = async (req, res) => {
  try {
    const jobId = req.params.id;
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        message: "No such job found",
        success: false,
      });
    }

    const userId = req.id;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({
        message: "No Such User Found",
        success: false,
      });
    }

    if (job?.owner?._id.toString() !== userId) {
      return res.status(403).json({
        message: "You Are Not Authorized to make this action",
        success: false,
      });
    }
    const { action } = req.body;

    if (user?.role === "freelancer" && action === "sendForReview") {
      job.status = "paused";
    } else if (user?.role === "client" && action === "redo") {
      job.status = "progress";
    } else if (user?.role === "client" && action === "accept") {
      job.status = "completed";
    } else {
      return res.status(400).json({
        message: "Invalid action or role",
        success: false,
      });
    }

    await job.save();
    return res.status(200).json({
      message: `Job Status Updated to ${job?.status}`,
      success: true,
      job,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};

export const raiseJobDispute = async (req, res) => {
  try {
    const jobId = req.params.id;
    const userId = req.id;
    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({
        message: "No such job found",
        success: false,
      });
    }

    if (
      job.client.toString() !== userId &&
      job.freelancer.toString() !== userId
    ) {
      return res.status(403).json({
        message: "You are not authorized to raise a dispute",
        success: false,
      });
    }

    job.status = "disputes";

    await job.save();
    return res.status(200).json({
      message: "Job Status Updated to disputes",
      success: true,
    });
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Internal Server Error",
      success: false,
    });
  }
};


